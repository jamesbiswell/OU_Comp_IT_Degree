import unittest

from esp_prog_8_3_and_9_1_name_check import namecheck

class TestNameCheck (unittest.TestCase):

	def test_alphaname(self):
		self.assertTrue(namecheck('Sommerville'))

	def test_namewithquote(self):
		self.assertTrue(namecheck("O'Reilly"))

	def test_namewithhyphen(self):
		self.assertTrue(namecheck('Washington-Wilson'))

	def test_shortname(self):
		self.assertTrue(namecheck('Sx'))

	def test_namewithdigit(self):
		self.assertFalse(namecheck('C-3PO'))

	def test_namewithinvalidchar(self):
		self.assertFalse(namecheck('Sommer_ville'))

	def test_nametooshort(self):
		self.assertFalse(namecheck ('S'))

	def test_nametoolong(self):
		self.assertFalse(namecheck('Thisisalongstringwithmorethen40charactersfrombeginningtoend'))

	def test_doublequote(self):
		self.assertFalse(namecheck("Thisis'maliciouscode'"))

	def test_namewithdoublehyphen(self):
		self.assertFalse(namecheck('--badcode'))

	def test_namewithspaces(self):
		self.assertFalse(namecheck('Washington Wilson'))

	def test_namestartswithhyphen(self):
		self.assertFalse(namecheck('-Sommerville'))

	def test_namestartswithquote (self):
		self.assertFalse(namecheck("'Reilly"))

if __name__ == "__main__":
	unittest.main()